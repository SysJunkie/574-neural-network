The order in which the variables were dumped to the pickle are as follows:

1. selected_features
2. n_hidden
3. w1
4. w2
5. lambdaval